# Our Stories Café – Mobile App

A React Native + Expo prototype for a café/food ordering application.

## Included
- Café home/menu
- Categories
- Add to cart
- Quantity controls
- Checkout
- Delivery option (₹40 demo fee)
- Pickup option (₹0)
- Order confirmation and status
- Professional mobile-first UI

## Run on your laptop
1. Install Node.js (LTS).
2. Open this folder in VS Code.
3. Open Terminal.
4. Run:
   npm install
   npx expo start

## Test on Android phone
Install **Expo Go** from Google Play. Make sure your phone and laptop are on the same Wi-Fi, then scan the QR code shown by Expo.

This is a front-end prototype. Real payment, database, maps, authentication, and live delivery tracking can be connected later.
