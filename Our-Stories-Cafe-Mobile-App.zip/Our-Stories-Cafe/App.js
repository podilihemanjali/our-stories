import React, {useMemo, useState} from 'react';
import {View, Text, StyleSheet, FlatList, TouchableOpacity, ScrollView, Alert} from 'react-native';
import {NavigationContainer} from '@react-navigation/native';
import {createNativeStackNavigator} from '@react-navigation/native-stack';
import {Ionicons} from '@expo/vector-icons';
import {StatusBar} from 'expo-status-bar';

const MENU = [
  {id:'1', name:'Cappuccino', price:140, cat:'Coffee', icon:'☕', desc:'Rich espresso with creamy foam'},
  {id:'2', name:'Cold Coffee', price:160, cat:'Coffee', icon:'🧋', desc:'Chilled coffee with smooth cream'},
  {id:'3', name:'Masala Tea', price:80, cat:'Tea', icon:'🍵', desc:'Classic Indian spiced tea'},
  {id:'4', name:'French Fries', price:120, cat:'Snacks', icon:'🍟', desc:'Crispy golden fries'},
  {id:'5', name:'Veg Sandwich', price:150, cat:'Snacks', icon:'🥪', desc:'Fresh veggies and cheese'},
  {id:'6', name:'Chocolate Cake', price:180, cat:'Desserts', icon:'🍰', desc:'Soft chocolate cake slice'}
];

function Home({navigation}) {
  const [cat,setCat]=useState('All');
  const [cart,setCart]=useState({});
  const items=cat==='All'?MENU:MENU.filter(x=>x.cat===cat);
  const count=Object.values(cart).reduce((a,b)=>a+b,0);
  return <View style={s.page}>
    <StatusBar style="dark"/>
    <View style={s.header}><View><Text style={s.logo}>Our Stories</Text><Text style={s.sub}>CAFÉ • COFFEE • STORIES</Text></View>
      <TouchableOpacity onPress={()=>navigation.navigate('Cart',{cart})} style={s.cart}><Ionicons name="cart-outline" size={25}/>{count>0&&<Text style={s.badge}>{count}</Text>}</TouchableOpacity>
    </View>
    <ScrollView horizontal showsHorizontalScrollIndicator={false} style={s.cats}>
      {['All','Coffee','Tea','Snacks','Desserts'].map(x=><TouchableOpacity key={x} onPress={()=>setCat(x)} style={[s.cat,cat===x&&s.catOn]}><Text style={[s.catText,cat===x&&s.catTextOn]}>{x}</Text></TouchableOpacity>)}
    </ScrollView>
    <View style={s.hero}><Text style={s.heroSmall}>WELCOME TO</Text><Text style={s.heroTitle}>Our Stories Café</Text><Text style={s.heroDesc}>Good coffee. Great food. Better stories.</Text></View>
    <FlatList data={items} keyExtractor={x=>x.id} contentContainerStyle={{padding:16,paddingBottom:30}} renderItem={({item})=><View style={s.card}>
      <View style={s.foodIcon}><Text style={{fontSize:42}}>{item.icon}</Text></View>
      <View style={{flex:1,marginLeft:14}}><Text style={s.foodName}>{item.name}</Text><Text style={s.foodDesc}>{item.desc}</Text><Text style={s.price}>₹{item.price}</Text></View>
      <TouchableOpacity style={s.add} onPress={()=>setCart({...cart,[item.id]:(cart[item.id]||0)+1})}><Text style={s.addText}>+</Text></TouchableOpacity>
    </View>)}/>
  </View>
}

function Cart({route,navigation}) {
  const [cart,setCart]=useState(route.params?.cart||{});
  const rows=MENU.filter(x=>cart[x.id]);
  const total=rows.reduce((a,x)=>a+x.price*cart[x.id],0);
  const update=(id,n)=>setCart({...cart,[id]:Math.max(0,n)});
  return <View style={s.page}><ScrollView contentContainerStyle={{padding:18}}>
    <Text style={s.title}>Your Cart</Text>
    {rows.length===0?<Text style={s.empty}>Your cart is empty.</Text>:rows.map(x=><View style={s.row} key={x.id}><Text style={{fontSize:30}}>{x.icon}</Text><View style={{flex:1,marginLeft:12}}><Text style={s.foodName}>{x.name}</Text><Text>₹{x.price} × {cart[x.id]}</Text></View><View style={s.qty}><TouchableOpacity onPress={()=>update(x.id,cart[x.id]-1)}><Text style={s.q}>−</Text></TouchableOpacity><Text style={s.q}>{cart[x.id]}</Text><TouchableOpacity onPress={()=>update(x.id,cart[x.id]+1)}><Text style={s.q}>+</Text></TouchableOpacity></View></View>)}
    {rows.length>0&&<><View style={s.total}><Text>Subtotal</Text><Text style={s.totalText}>₹{total}</Text></View><TouchableOpacity style={s.primary} onPress={()=>navigation.navigate('Checkout',{total})}><Text style={s.primaryText}>Continue to Checkout</Text></TouchableOpacity></>}
  </ScrollView></View>
}

function Checkout({route,navigation}) {
 const total=route.params?.total||0; const [type,setType]=useState('Delivery');
 return <View style={s.page}><ScrollView contentContainerStyle={{padding:18}}><Text style={s.title}>Checkout</Text>
 <Text style={s.section}>Choose order type</Text>
 <TouchableOpacity style={[s.option,type==='Delivery'&&s.selected]} onPress={()=>setType('Delivery')}><Text style={{fontSize:28}}>🛵</Text><View style={{flex:1,marginLeft:12}}><Text style={s.optionTitle}>Delivery</Text><Text style={s.muted}>Delivered to your address</Text></View><Ionicons name={type==='Delivery'?'radio-button-on':'radio-button-off'} size={24}/></TouchableOpacity>
 <TouchableOpacity style={[s.option,type==='Pickup'&&s.selected]} onPress={()=>setType('Pickup')}><Text style={{fontSize:28}}>🏪</Text><View style={{flex:1,marginLeft:12}}><Text style={s.optionTitle}>Pickup</Text><Text style={s.muted}>Collect from Our Stories Café</Text></View><Ionicons name={type==='Pickup'?'radio-button-on':'radio-button-off'} size={24}/></TouchableOpacity>
 {type==='Delivery'&&<View style={s.address}><Text style={s.section}>Delivery address</Text><Text style={s.addressText}>123, Main Street, Your City</Text><Text style={s.muted}>Demo address — editable in the full version</Text></View>}
 <View style={s.bill}><Text>Subtotal</Text><Text>₹{total}</Text><Text>{type==='Delivery'?'Delivery fee':'Pickup fee'}</Text><Text>{type==='Delivery'?'₹40':'₹0'}</Text><View style={s.line}/><Text style={s.totalText}>Total</Text><Text style={s.totalText}>₹{total+(type==='Delivery'?40:0)}</Text></View>
 <TouchableOpacity style={s.primary} onPress={()=>navigation.navigate('Success',{type})}><Text style={s.primaryText}>Place {type} Order</Text></TouchableOpacity>
 </ScrollView></View>
}

function Success({route,navigation}) {const type=route.params?.type||'Delivery'; return <View style={s.success}><Text style={{fontSize:70}}>✅</Text><Text style={s.successTitle}>Order Placed!</Text><Text style={s.successText}>{type==='Delivery'?'Your order will be delivered soon.':'Your order is being prepared. We’ll notify you when it is ready for pickup.'}</Text><Text style={s.order}>Order #OS1024</Text><View style={s.track}><Text>✓ Order Placed</Text><Text>→ Preparing</Text><Text>→ {type==='Delivery'?'Out for Delivery':'Ready for Pickup'}</Text></View><TouchableOpacity style={s.primary} onPress={()=>navigation.popToTop()}><Text style={s.primaryText}>Back to Café</Text></TouchableOpacity></View>}

const Stack=createNativeStackNavigator();
export default function App(){return <NavigationContainer><Stack.Navigator screenOptions={{headerShown:false}}><Stack.Screen name="Home" component={Home}/><Stack.Screen name="Cart" component={Cart}/><Stack.Screen name="Checkout" component={Checkout}/><Stack.Screen name="Success" component={Success}/></Stack.Navigator></NavigationContainer>}

const s=StyleSheet.create({
 page:{flex:1,backgroundColor:'#FFFDF9'},header:{padding:18,paddingTop:52,flexDirection:'row',justifyContent:'space-between',alignItems:'center',backgroundColor:'#FFF'},logo:{fontSize:27,fontWeight:'800'},sub:{fontSize:10,letterSpacing:2,marginTop:2},cart:{padding:8},badge:{position:'absolute',right:0,top:0,backgroundColor:'#8B5E3C',color:'#fff',borderRadius:10,minWidth:18,textAlign:'center',fontSize:11},cats:{paddingHorizontal:12,maxHeight:58},cat:{paddingVertical:11,paddingHorizontal:17,borderRadius:22,marginHorizontal:4,backgroundColor:'#F1ECE5'},catOn:{backgroundColor:'#8B5E3C'},catText:{color:'#5C5147'},catTextOn:{color:'#fff',fontWeight:'700'},hero:{margin:16,padding:24,borderRadius:20,backgroundColor:'#EDE0D2'},heroSmall:{fontSize:11,letterSpacing:2},heroTitle:{fontSize:27,fontWeight:'800',marginTop:5},heroDesc:{marginTop:6,color:'#64584D'},card:{backgroundColor:'#fff',borderRadius:18,padding:12,marginBottom:12,flexDirection:'row',alignItems:'center',elevation:2},foodIcon:{width:72,height:72,borderRadius:16,backgroundColor:'#F7F0E8',alignItems:'center',justifyContent:'center'},foodName:{fontSize:17,fontWeight:'700'},foodDesc:{fontSize:12,color:'#81766C',marginVertical:3},price:{fontWeight:'800',marginTop:3},add:{width:38,height:38,borderRadius:19,backgroundColor:'#8B5E3C',alignItems:'center',justifyContent:'center'},addText:{color:'#fff',fontSize:25},title:{fontSize:28,fontWeight:'800',marginBottom:22},empty:{textAlign:'center',marginTop:60,color:'#777'},row:{backgroundColor:'#fff',padding:14,borderRadius:16,marginBottom:10,flexDirection:'row',alignItems:'center'},qty:{flexDirection:'row',gap:10,alignItems:'center'},q:{fontSize:20,fontWeight:'700'},total:{borderTopWidth:1,borderColor:'#ddd',marginTop:15,paddingTop:18,flexDirection:'row',justifyContent:'space-between'},totalText:{fontWeight:'800',fontSize:18},primary:{backgroundColor:'#8B5E3C',padding:16,borderRadius:14,alignItems:'center',marginTop:22},primaryText:{color:'#fff',fontWeight:'800',fontSize:16},section:{fontSize:16,fontWeight:'800',marginBottom:10,marginTop:8},option:{backgroundColor:'#fff',padding:16,borderRadius:16,marginBottom:12,flexDirection:'row',alignItems:'center',borderWidth:1,borderColor:'#eee'},selected:{borderColor:'#8B5E3C',backgroundColor:'#FBF5EF'},optionTitle:{fontWeight:'800',fontSize:16},muted:{color:'#81766C',fontSize:12,marginTop:3},address:{backgroundColor:'#F7F0E8',padding:16,borderRadius:15,marginTop:8},addressText:{fontWeight:'700',marginBottom:4},bill:{backgroundColor:'#fff',padding:18,borderRadius:16,marginTop:18,display:'flex',gap:10},line:{height:1,backgroundColor:'#ddd',marginVertical:4},success:{flex:1,backgroundColor:'#FFFDF9',alignItems:'center',justifyContent:'center',padding:28},successTitle:{fontSize:30,fontWeight:'800',marginTop:15},successText:{textAlign:'center',color:'#665C54',lineHeight:22,marginTop:10},order:{fontWeight:'800',marginTop:16},track:{width:'100%',backgroundColor:'#F7F0E8',padding:18,borderRadius:16,marginTop:20,gap:12}
});
